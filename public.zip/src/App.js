import 'bootstrap/dist/css/bootstrap.min.css';
import ProductCatalog from './Component/ProductCatalog';


function App() {
  return (
    <ProductCatalog />

  );
}

export default App;
